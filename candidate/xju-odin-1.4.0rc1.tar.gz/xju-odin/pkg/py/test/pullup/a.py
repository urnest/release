
def x():
    pass
