#ifndef TPS_DRVPTH
#define TPS_DRVPTH

#include <dg/inc/Type.hh>

typedef struct _tps_DrvPth {
   tp_DPType DPType;
   tp_FKind FKind;
   tp_FilTyp FilTyp;
   tp_DrvEdg DrvEdg;
   tp_DrvPth Next;
   bool InUse;
   }				tps_DrvPth;

#endif
