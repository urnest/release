#ifdef BUILDING_DG
#include <dg/inc/DgTokTyp_.h>
#endif
#ifdef BUILDING_ODIN
#include <odin/inc/OdinTokTyp_.h>
#endif
