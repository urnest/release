#ifndef TP_DPTYPE
#define TP_DPTYPE

enum DPType {
  DPT_Cast =1,
  DPT_Eqv =2,
  DPT_Drv =3
};

#endif
