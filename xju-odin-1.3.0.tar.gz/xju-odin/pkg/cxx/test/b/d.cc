#include "b/d.h"

std::string d() throw()
{
  return "d";
}

