#!/usr/bin/env python3
from sys import path
del path[0]

import i
import sys

print(sys.argv[1])

