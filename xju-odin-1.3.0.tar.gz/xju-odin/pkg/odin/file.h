#ifndef ODIN_FILE_H
#define ODIN_FILE_H

#include <gmc/gmc.h>
#include <odin/inc/Type.hh>
#include <odin/inc/SKind_.h>

extern void Get_FileInfo(tp_SKind* SKindPtr,int* SysModTimePtr,tp_FileName FileName);

#endif
