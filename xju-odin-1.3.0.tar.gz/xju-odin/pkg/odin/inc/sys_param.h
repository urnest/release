#ifndef SYS_PARAM_H
#define SYS_PARAM_H

#ifndef HAVE_SYS_PARAM_H

#define MAXHOSTNAMELEN 258

#else

#include <sys/param.h>

#endif
#endif
