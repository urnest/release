#ifndef ODIN_FUNC_H
#define ODIN_FUNC_H

#include <gmc/gmc.h>
#include <odin/inc/Type.hh>
#include <sys/select.h>
#include <odin/file.h>

/* if-bcast.c */
extern void Broadcast(tp_FilHdr FilHdr, tp_Status Status);
extern void Broadcast_Mod(tp_FilHdr, tp_ModKind, tp_Status);
/* if-build.c */
extern tp_Build JobID_Build(tp_JobID);
extern void Extend_Builds(int);
extern void Set_BuildHosts(bool *, tp_Str);
extern void Write_BuildHosts(tp_FilDsc);
extern void Local_Add_BuildArg(tp_FileName);
extern void Local_Do_Build(tp_JobID, tp_FileName, tp_FileName);
extern void Local_Abort_Build(tp_JobID);
extern void SystemExecCmdWait(bool *, const char *, bool);
extern void ChildAction(bool *, bool *);
extern void Cancel_Builds(tp_Host);
extern void Build_Done(tp_Build, bool);
extern void Local_Do_MakeReadOnly(tp_FileName);
/* if-candrv.c */
extern tp_DrvPth Get_DrvPth(tp_FilHdr, tp_FilTyp);
extern tp_PrmTypLst DrvPth_PrmTypLst(tp_DrvPth);
extern tp_DrvPth Find_GroupingDrvPthElm(tp_DrvPth);
extern tp_FilHdr Do_DrvPth(tp_FilHdr, tp_FilPrm, tp_FilPrm, tp_DrvPth);
extern tp_FilHdr Do_Deriv(tp_FilHdr, tp_FilPrm, tp_FilPrm, tp_FilTyp);
extern tp_FilHdr Do_Key(tp_FilHdr, tp_Key);
// set *Result to existing FilHdr of specified Key, or return False
// - note return true does not necessarily mean that Is_Source(*Result)
//   (but does mean that key was already known)
// - note will return false in some cases where the key is known but
//   cannot be/lead to a source file
extern bool Do_Existing_Src_Key(tp_FilHdr, tp_Key, tp_FilHdr* Result);
extern tp_FilHdr Str_FilHdr(tp_Str, tp_PrmTyp);
extern tp_FilHdr Do_VTgt(tp_FilHdr, tp_Key);
extern void WriteDrvHelp(tp_FilDsc, tp_FilHdr);
extern void WritePrmHelp(tp_FilDsc, tp_FilHdr, tp_FilPrm);
extern void WriteNameDesc(tp_FilDsc, tp_Str, tp_Desc);
extern tp_FilHdr Get_BaseVTgtFilHdr(tp_FilHdr);

extern tp_PrmFHdr Nod_PrmFHdr(tp_Nod);
extern bool Nod_Existing_Src_PrmFHdr(tp_Nod, tp_PrmFHdr* Result);

extern tp_LocElm Make_ApplyLocElm(tp_FilHdr, tp_FilHdr, tp_FileName);
extern tp_LocElm Make_MapLocElm(tp_FilHdr, tp_FilHdr);
extern tp_LocElm Make_RecurseLocElm(tp_FilHdr, tp_FilHdr);
extern void Local_Get_OdinFile(tp_Str, bool);
extern void End_Get_OdinFile();
/* if-client.c */
extern void Ret_ToDo();
extern tp_Client New_Client(tp_ClientID);
extern void Activate_Client(tp_Client);
extern void Ret_Client(tp_Client);
extern void Purge_Clients();
extern bool Is_ActiveClient(tp_Client);
extern int Client_FD(tp_Client);
extern bool Client_Interrupted(tp_Client);
extern void Set_Client_Interrupted(tp_Client, bool);
extern bool Client_KeepGoing(tp_Client);
extern int Client_ErrLevel(tp_Client);
extern int Client_WarnLevel(tp_Client);
extern tp_LogLevel Client_LogLevel(tp_Client);
extern tp_FilHdr Client_FilHdr(tp_Client);
extern void Set_Client_FilHdr(tp_Client, tp_FilHdr, bool);
extern bool Client_NeedsData(tp_Client);
extern void Push_AllReqs();
extern tp_FHLst Client_ToDo(tp_Client);
extern void Push_ToDo(tp_FilHdr);
extern void Push_Pending(tp_FilHdr, tp_InpKind);
extern void Push_ToBroadcast(tp_FilHdr);
extern void Do_ToBroadcast();
extern tp_Job Client_Job(tp_Client);
extern tp_Client Client_Next(tp_Client);
extern bool Is_LocalClient(tp_Client);
extern bool Is_ServerAction();
extern tp_Job New_Job();
extern tp_Job Get_Job(tp_JobID);
extern void Ret_Job(tp_Job);
extern tp_FilHdr Job_FilHdr(tp_Job);
extern tp_Job Add_Job(tp_FilHdr);
extern void Del_Job(tp_Job);
extern void Clr_Status(tp_FilHdr);
extern bool Is_TgtValErrStatus(tp_FilHdr);
extern tp_FilHdr FilHdr_TgtValFilHdr(tp_FilHdr);
extern void ServerAction();
extern void Local_Do_Interrupt(bool);
extern bool IsAny_ServerAction();
extern tp_FilHdr Top_CWDFilHdr();
extern tp_FilHdr Top_ContextFilHdr();
extern void Push_ContextFilHdr(tp_FilHdr);
extern void Pop_ContextFilHdr();
extern void Local_Set_CWD(tp_FileName);
extern void Local_Push_Context(tp_FileName, tp_FileName);
extern void Local_Pop_Context(tp_FileName);
extern void Local_Set_KeepGoing(bool);
extern void Local_Set_ErrLevel(int);
extern void Local_Set_WarnLevel(int);
extern void Local_Set_LogLevel(tp_LogLevel);
extern void Local_Set_HelpLevel(tp_LogLevel);
extern void Local_Set_MaxJobs(int);
extern int Local_Get_NumJobs();
extern void Local_Get_UseCount(int *);
/* if-cmd.c */
extern void CommandInterpreter(bool *, tp_Nod, bool);
extern bool IsIncremental_MsgLevel(int);
extern void UtilityHelp();
extern void UtilityDefaultHelp();
extern void Print_Banner();
/* if-depend.c */
extern void WriteReport(tp_FilDsc, tp_FilHdr, tp_Status);
extern void GetDepend(tp_LocElm *, tp_LocElm *, tp_FilHdr, tp_FilHdr);
extern void Local_Get_DPath(tp_Str);
/* if-dir.c */
extern tp_FilDsc OpenDir(tp_FileName);
extern void CloseDir(tp_FilDsc);
extern void ReadDir(tp_FileName, bool *, tp_FilDsc);
extern void ClearDir(tp_FileName);
/* if-drvgrf.c */
extern tp_FilTyp IFilTyp_FilTyp(int);
extern tp_PrmTyp IPrmTyp_PrmTyp(int);
extern tp_PrmTyp I_PrmTyp(int);
extern void Read_DrvGrf();
extern void Local_Get_Banner(tp_Str);
/* if-drvpth.c */
extern void AppendDrvPth(tp_DrvPth *, tp_DrvPth);
extern tp_DrvPth FilTyp_Cast_DrvPth(tp_FilTyp);
extern tp_DrvPth FilTyp_Eqv_DrvPth(tp_FilTyp);
extern tp_DrvPth FilTyp_Drv_DrvPth(tp_FilTyp, tp_DrvEdg);
extern void Ret_DrvPth(tp_DrvPth);
extern tp_DPType DrvPth_DPType(tp_DrvPth);
extern tp_FKind DrvPth_FKind(tp_DrvPth);
extern tp_FilTyp DrvPth_FilTyp(tp_DrvPth);
extern tp_DrvEdg DrvPth_DrvEdg(tp_DrvPth);
extern tp_DrvPth DrvPth_Next(tp_DrvPth);
/* if-drvspc.c */
extern void Print_FilHdr(tp_FilDsc, tp_Str, tp_FilHdr);
extern void SPrint_FilHdr(tp_Str, tp_FilHdr);
extern void VerboseSPrint_FilHdr(tp_Str, tp_FilHdr);
/* if-edg.c */
extern tp_PrmTypLst DrvEdg_PrmTypLst(tp_DrvEdg);
extern tp_InpSpc InpEdg_InpSpc(tp_InpEdg);
extern tp_InpKind InpEdg_InpKind(tp_InpEdg);
extern bool InpEdg_IsUserArg(tp_InpEdg);
extern tp_InpEdg InpEdg_Next(tp_InpEdg);
extern tp_FilTyp EqvEdg_FilTyp(tp_EqvEdg);
extern tp_FilTyp MemEdg_FilTyp(tp_MemEdg);
extern bool InpKind_IsAnyOK(tp_InpKind);
extern bool NeedsData(tp_FilHdr, tp_InpKind);
extern bool NeedsElmData(tp_FilHdr, tp_InpKind);
extern bool NeedsElmNameData(tp_FilHdr, tp_InpKind);
extern int NumInputs(tp_FilTyp);
extern void GetOutTyps(tp_FilTyp, tp_OutTyps, int *);
extern void SetEqvEdg_Marks(tp_EqvEdg, bool, bool);
extern void SetCastEdg_Marks(tp_CastEdg, bool);
extern void SetDrvEdg_Marks(tp_DrvEdg, bool);
/* if-env.c */
extern void Get_SocketFileName(tp_FileName);
extern void Get_DGFileName(tp_FileName);
extern void Get_PkgDirName(tp_FileName, tp_Package);
extern void Get_InfoFileName(tp_FileName);
extern void Get_DebugFileName(tp_FileName);
extern void Get_WorkFileName(tp_FileName, tp_Job, tp_FilHdr);
extern void JobID_LogFileName(tp_FileName, int);
extern void Local_ShutDown();
extern void Init_Env();
extern void Write_ENV2();
extern void Read_ENV2();
extern bool IsDef_EnvVar(tp_Str);
extern void Init_CWD();
extern void DeadServerExit();
extern void Exit(int);
/* if-err.c */
extern void Set_IPC_Err(bool);
extern void Set_ErrFile(tp_FileName, bool, tp_FilDsc);
extern void Save_ErrFile(tp_FileName *, bool *, tp_FilDsc *);
extern bool IsErr();
extern void Reset_Err();
extern void Increment_Errors();
extern int Num_Errors();
extern void SysCallError(tp_FilDsc, char *);
extern void SystemError(char *, ...);
extern void Local_ErrMessage(tp_Str);
/* if-exec.c */
extern void Exec(tp_FilHdr);
extern void Local_Job_Done(tp_JobID, bool);
/* if-execint.c */
extern void ExecInternal(tp_FilHdr, tp_Status, tp_Date);
/* if-execspc.c */
extern tp_Tool FilHdr_Tool(tp_FilHdr);
extern void FilHdr_ExecSpc(tp_ExecSpc, tp_FilHdr);
extern void Get_OutFilHdrs(tp_OutFilHdrs, int *, tp_FilHdr);
extern void Ret_ExecSpc(tp_ExecSpc);
/* if-fhacc.c */
extern bool IsSource_FKind(tp_FKind);
extern bool IsSource(tp_FilHdr);
extern bool IsSymLink(tp_FilHdr);
extern bool IsDir(tp_FilHdr);
extern bool IsStr(tp_FilHdr);
extern bool IsBound(tp_FilHdr);
extern bool IsATgt(tp_FilHdr);
extern bool IsVTgt(tp_FilHdr);
extern bool IsVTgtText(tp_FilHdr);
extern bool IsDfltTgtVal(tp_FilHdr);
extern bool IsPntr(tp_FilHdr);
extern bool IsGeneric(tp_FilHdr);
extern bool IsPipe(tp_FilHdr);
extern bool IsInstance(tp_FilHdr);
extern bool IsAtmc(tp_FilHdr);
extern bool IsList(tp_FilHdr);
extern bool IsViewSpec(tp_FilHdr);
extern bool IsStruct(tp_FilHdr);
extern bool IsStructMem(tp_FilHdr);
extern bool IsVoid(tp_FilHdr);
extern bool IsTargetsPtr(tp_FilHdr);
extern bool IsTargets(tp_FilHdr);
extern bool IsDrvDir(tp_FilHdr);
extern bool IsDrvDirElm(tp_FilHdr);
extern bool IsKeyList(tp_FilHdr);
extern bool IsKeyListElm(tp_FilHdr);
extern bool IsVirDir(tp_FilHdr);
extern bool IsCopy(tp_FilHdr);
extern bool IsAutoExec(tp_FilHdr);
extern bool HasKey_FKind(tp_FKind);
extern bool IsRef(tp_FilHdr);
extern tp_LocHdr FilHdr_LocHdr(tp_FilHdr);
extern tp_LocHdr FilHdr_AliasLocHdr(tp_FilHdr);
extern void Set_AliasLocHdr(tp_FilHdr, tp_LocHdr);
extern tp_FilHdr FilHdr_AliasFilHdr(tp_FilHdr);
extern tp_FKind FilHdr_FKind(tp_FilHdr);
extern void Set_FKind(tp_FilHdr, tp_FKind);
extern tp_FilTyp FilHdr_FilTyp(tp_FilHdr);
extern tp_FilPrm FilHdr_FilPrm(tp_FilHdr);
extern tp_Ident FilHdr_Ident(tp_FilHdr);
extern void Update_SrcFilHdr(tp_FilHdr, bool);
extern void FilHdr_Error(tp_Str, tp_FilHdr);
extern bool IsAllDone(tp_FilHdr, tp_InpKind);
extern bool IsAllUpToDate(tp_FilHdr, tp_InpKind);
extern bool IsSrcUpToDate(tp_FilHdr);
extern void SPrint_VerifyDate(tp_Str To,
                              tp_Str Leader,
                              tp_FilHdr FilHdr,
                              tp_Str Trailer);
extern void SPrint_TgtValVerifyDate(tp_Str To,
                                    tp_Str Leader,
                                    tp_FilHdr FilHdr,
                                    tp_Str Trailer);
extern bool IsUpToDate(tp_FilHdr);
extern bool IsElmNameUpToDate(tp_FilHdr);
extern bool IsElmUpToDate(tp_FilHdr);
extern bool IsTgtValUpToDate(tp_FilHdr);
extern tp_FilHdr FilHdr_Father(tp_FilHdr);
extern tp_FilHdr FilHdr_SrcFilHdr(tp_FilHdr);
extern tp_FilHdr FilHdr_DirFilHdr(tp_FilHdr);
extern tp_Str FilHdr_Key(tp_Str, tp_FilHdr);
extern tp_Label FilHdr_Label(tp_Str, tp_FilHdr, bool);
extern tp_FilHdr FilHdr_ElmFilHdr(tp_FilHdr);
/* if-fhnam.c */
extern tp_FilHdr Do_Keys(tp_FilHdr, tp_Key);
extern bool Do_Existing_Src_Keys(tp_FilHdr, tp_Key, tp_FilHdr* Result);

extern void FilHdr_DataFileName(tp_FileName, tp_FilHdr);
extern void FilHdr_ErrorFileName(tp_FileName, tp_FilHdr);
extern void FilHdr_WarningFileName(tp_FileName, tp_FilHdr);
extern void Local_Do_Alias(tp_FileName, bool);
extern void Local_Get_Alias(tp_FileName, tp_FileName);
extern void FilHdr_HostFN(tp_FileName, tp_FilHdr, bool);
extern tp_FilHdr HostFN_FilHdr(tp_FileName);
extern tp_FilHdr CacheFileName_FilHdr(tp_FileName);
extern tp_FilHdr DataFileName_FilHdr(tp_FileName);
/* if-fhnew.c */
extern void Make_RootHdrInf(tp_HdrInf, tp_LocHdr);
extern tp_FilHdr Insert_FilHdr(tp_FilHdr, tp_FKind, tp_FilTyp, tp_FilPrm, tp_Ident);
extern tp_FilHdr Extend_FilHdr(tp_FilHdr, tp_FKind, tp_FilTyp, tp_FilPrm, tp_Str);
extern bool Extend_Exsiting_Src_FilHdr(tp_FilHdr, tp_FKind, tp_FilTyp, tp_FilPrm, tp_Str, tp_FilHdr* Result);
extern tp_FilHdr Get_Drv(tp_FilHdr, tp_FKind, tp_FilTyp, tp_FilPrm, tp_Ident);
extern tp_FilHdr Get_KeyDrv(tp_FilHdr, tp_FKind, tp_Key);
extern bool Get_Existing_Src_KeyDrv(tp_FilHdr, tp_FKind, tp_Key, tp_FilHdr* Result);
/* if-fhsrc.c */
extern void Deref_Pntrs(tp_FilHdr *, tp_FilPrm *, tp_FilHdr, bool);
extern tp_FilHdr Deref(tp_FilHdr);
extern tp_FilHdr Deref_SymLink(tp_FilHdr);
extern void Local_Test(tp_FileName);
extern void Notify_Change(tp_FileName);
extern void Local_Test_All();
extern tp_FilHdr Get_Copy_DestFilHdr(tp_FilHdr);
extern tp_LocElm Make_CopyLocElm(tp_FilHdr, tp_FilHdr, tp_FilHdr);
extern void Exec_CopyCmd(tp_FilHdr, tp_FilHdr, tp_FilHdr);
/* if-fhstat.c */
extern bool Is_PendingReadyOrBusy_Status(tp_Status);
extern void Clr_ErrStatus(tp_FilHdr);
extern void Add_ErrStatus(tp_FilHdr, tp_Status);
extern bool FilHdr_HasErrStatus(tp_FilHdr, tp_Status);
extern tp_Status FilHdr_MinErrStatus(tp_FilHdr);
extern void Add_StatusFile(tp_FilHdr, tp_Status, tp_FileName);
extern void Set_DepStatus(tp_FilHdr, tp_Status);
extern tp_Status FilHdr_DepStatus(tp_FilHdr);
extern void Set_DepModDate(tp_FilHdr, tp_Date);
extern tp_Date FilHdr_DepModDate(tp_FilHdr);
extern void Set_Status(tp_FilHdr, tp_Status);
extern tp_Status FilHdr_Status(tp_FilHdr);
extern void Set_ElmNameStatus(tp_FilHdr, tp_Status);
extern tp_Status FilHdr_ElmNameStatus(tp_FilHdr);
extern void Set_ElmStatus(tp_FilHdr, tp_Status);
extern tp_Status FilHdr_ElmStatus(tp_FilHdr);
extern void Set_TgtValStatus(tp_FilHdr, tp_Status);
extern tp_Status FilHdr_TgtValStatus(tp_FilHdr);
extern tp_Status FilHdr_TgtValMinStatus(tp_FilHdr);
extern tp_Status FilHdr_MinStatus(tp_FilHdr, tp_InpKind);
extern void Set_ModDate(tp_FilHdr);
extern tp_Date FilHdr_ModDate(tp_FilHdr);
extern void Set_ConfirmDate(tp_FilHdr, tp_Date);
extern void Clr_ConfirmDate(tp_FilHdr);
extern tp_Date FilHdr_ConfirmDate(tp_FilHdr);
extern void Set_ElmNameConfirmDate(tp_FilHdr);
extern void Set_ElmConfirmDate(tp_FilHdr);
extern void Set_ElmModDate(tp_FilHdr, tp_Date);
extern tp_Date FilHdr_ElmModDate(tp_FilHdr);
extern void Set_ElmNameModDate(tp_FilHdr, tp_Date);
extern tp_Date FilHdr_ElmNameModDate(tp_FilHdr);
extern void Set_Flag(tp_FilHdr, tp_Flag);
extern void Clr_Flag(tp_FilHdr, tp_Flag);
extern bool FilHdr_Flag(tp_FilHdr, tp_Flag);
extern void Set_AnyOKDepth(tp_FilHdr, int);
extern int FilHdr_AnyOKDepth(tp_FilHdr);
extern void Set_ElmDepth(tp_FilHdr, int);
extern int FilHdr_ElmDepth(tp_FilHdr);
extern void Set_ElmTag(tp_FilHdr, int);
extern int FilHdr_ElmTag(tp_FilHdr);
extern void Set_SCC(tp_FilHdr, tp_FilHdr);
extern tp_FilHdr FilHdr_SCC(tp_FilHdr);
extern void Set_ListPndFlag(tp_FilHdr, bool);
extern void Set_PndFlag(tp_FilHdr, bool);
extern bool FilHdr_PndFlag(tp_FilHdr);
extern void Set_ElmNamePndFlag(tp_FilHdr, bool);
extern bool FilHdr_ElmNamePndFlag(tp_FilHdr);
extern void Set_ElmPndFlag(tp_FilHdr, bool);
extern bool FilHdr_ElmPndFlag(tp_FilHdr);
extern void Set_TgtValPndFlag(tp_FilHdr, bool);
extern bool FilHdr_TgtValPndFlag(tp_FilHdr);
extern tp_LocInp FilHdr_LocInp(tp_FilHdr);
extern void Set_LocElm(tp_FilHdr, tp_LocElm);
extern tp_LocElm FilHdr_LocElm(tp_FilHdr);
extern void Set_OldLocElm(tp_FilHdr);
extern tp_LocElm FilHdr_OldLocElm(tp_FilHdr);
extern void Set_TgtValLocElm(tp_FilHdr, tp_LocElm);
extern void Set_DfltTgtValLocElm(tp_FilHdr);
extern tp_LocElm FilHdr_TgtValLocElm(tp_FilHdr);
extern bool FilHdr_ActTgtInstalled(tp_FilHdr);
extern void Set_ActTgtInstalled(tp_FilHdr, bool);
extern void Set_InpLink(tp_FilHdr, tp_LocInp);
extern tp_LocInp FilHdr_InpLink(tp_FilHdr);
extern void Set_ElmLink(tp_FilHdr, tp_LocElm);
extern tp_LocElm FilHdr_ElmLink(tp_FilHdr);
extern int FilHdr_Size(tp_FilHdr);
extern void Set_Size(tp_FilHdr, int);
extern bool Data_Exists(tp_FilHdr);
extern void Local_Get_CurSize(int *);
extern void Set_OrigLocHdr(tp_FilHdr, tp_LocHdr);
extern tp_LocHdr FilHdr_OrigLocHdr(tp_FilHdr);
extern void Set_OrigModDate(tp_FilHdr, tp_Date);
extern tp_Date FilHdr_OrigModDate(tp_FilHdr);
/* if-file.c */
extern void Set_ModeMask(tp_FileName);
extern void MakePlnFile(bool *, tp_FileName);
extern void MakeDirFile(bool *, tp_FileName);
extern void GetWorkingDir(bool *, tp_Str);
extern void ChangeDir(bool *, tp_FileName);
extern bool IsExecutable(tp_FileName);
extern void MakeExecutable(tp_FileName);
extern void MakeReadOnly(bool *, tp_FileName);
extern void MakeReadWrite(bool *, tp_FileName);
extern void SymLink(bool *, tp_FileName, tp_FileName);
extern void FileName_SymLinkFileName(tp_FileName, tp_FileName);
extern bool IsDirectory_FileName(tp_FileName);
extern bool Exists(tp_FileName);
extern bool Empty(tp_FileName);
extern void FileSize(bool *, int *, tp_FileName);
extern void Remove(tp_FileName);
extern void RemoveDir(tp_FileName);
extern void Rename(bool *, tp_FileName, tp_FileName);
/* if-filelm.c */
extern void Init_FilElms();
extern void Ret_FilElm(tp_FilElm);
extern void Free_FilElms();
extern tp_FilElm LocElm_FilElm(tp_LocElm);
extern void WriteFilElms();
extern void DeAlloc_ElmInf(tp_LocElm);
extern bool FilElms_InUse();
extern tp_LocHdr FilElm_LocHdr(tp_FilElm);
extern tp_FilHdr FilElm_FilHdr(tp_FilElm);
extern tp_LocHdr FilElm_ListLocHdr(tp_FilElm);
extern tp_FilHdr FilElm_ListFilHdr(tp_FilElm);
extern tp_FilPrm FilElm_FilPrm(tp_FilElm);
extern tp_LocElm FilElm_Next(tp_FilElm);
extern tp_FilElm FilElm_NextFilElm(tp_FilElm);
extern tp_LocElm FilElm_Link(tp_FilElm);
extern tp_LocElm Make_LocElm(tp_FilHdr, tp_FilPrm, tp_FilHdr);
extern void Chain_LocElms(tp_LocElm *, tp_LocElm *, tp_LocElm);
extern bool IsEquiv_LocElms(tp_LocElm, tp_LocElm);
/* if-filhdr.c */
extern void Init_FilHdrs();
extern void Init_FilHdrTree();
extern tp_LocHdr Alloc_HdrInf();
extern tp_FilHdr Copy_FilHdr(tp_FilHdr);
extern void Ret_FilHdr(tp_FilHdr);
extern void Free_FilHdrs();
extern tp_FilHdr New_FilHdr();
extern tp_FilHdr LocHdr_FilHdr(tp_LocHdr);
extern void Init_HdrInf(tp_HdrInf);
extern void SetModified(tp_FilHdr);
extern void WriteFilHdrs();
extern bool FilHdrs_InUse();
extern void CleanUp();
/* if-filinp.c */
extern void Init_FilInps();
extern void Ret_FilInp(tp_FilInp);
extern void Free_FilInps();
extern tp_FilInp LocInp_FilInp(tp_LocInp);
extern void WriteFilInps();
extern bool FilInps_InUse();
extern tp_FilHdr FilInp_FilHdr(tp_FilInp);
extern tp_LocHdr FilInp_OutLocHdr(tp_FilInp);
extern int FilInp_IArg(tp_FilInp);
extern tp_InpKind FilInp_InpKind(tp_FilInp);
extern tp_FilInp FilInp_NextFilInp(tp_FilInp);
extern tp_LocInp FilInp_Link(tp_FilInp);
extern tp_LocInp Make_LocInp(tp_FilHdr, int, tp_InpKind, tp_FilHdr);
extern void Chain_LocInps(tp_LocInp *, tp_LocInp *, tp_LocInp);
extern tp_LocInp Get_LocInp(tp_FilHdr);
/* if-filprm.c */
extern void Init_FilPrm();
extern void Add_RootLocPVal(tp_PrmTyp, tp_LocPVal);
extern bool Equal_FilPrm(tp_FilPrm, tp_FilPrm);
extern tp_FilPrm Append_PrmInf(tp_FilPrm, tp_PrmTyp, tp_LocHdr, tp_LocPVal);
extern tp_FilPrm Append_FilPrm(tp_FilPrm, tp_FilPrm);
extern tp_LocPrm FilPrm_LocPrm(tp_FilPrm);
extern tp_FilPrm LocPrm_FilPrm(tp_LocPrm);
extern tp_FilPrm Strip_FilPrm(tp_FilPrm, tp_PrmTypLst);
extern tp_FilPrm StripExcept_FilPrm(tp_FilPrm, tp_PrmTyp);
extern tp_FilPVal FilPrm_FilPVal(tp_FilPrm);
extern tp_FilPVal Get_FilPVal(tp_FilPrm, tp_PrmTyp);
extern tp_FilPrm FilPrm_DerefPrmVal(tp_FilPrm);
extern void Chain_FilPrm_DerefPrmVal(tp_LocInp *, tp_LocInp *, tp_FilPrm, tp_FilHdr);
extern tp_FilHdr Get_FPVFilHdr(tp_PrmTyp, tp_FilPrm);
extern void Print_FilPrm(tp_FilDsc, tp_Str, tp_FilPrm);
extern void SetPrmTypLst_Marks(tp_PrmTypLst);
/* if-filpval.c */
extern tp_FilPVal New_FilPVal();
extern bool IsRootFilPVal(tp_FilPVal);
extern tp_FilPVal Add_PValInf(tp_FilPVal, tp_LocHdr, tp_LocPVal);
extern tp_FilPVal Append_PValInf(tp_FilPVal, tp_LocHdr, tp_LocPVal);
extern tp_FilPVal Append_FilPVal(tp_FilPVal, tp_FilPVal);
extern tp_LocPVal FilPVal_LocPVal(tp_FilPVal);
extern tp_FilPVal LocPVal_FilPVal(tp_LocPVal);
extern void Print_FilPVal(tp_FilDsc, tp_Str, tp_PrmTyp, tp_FilPVal);
extern tp_LocHdr FilPVal_LocHdr(tp_FilPVal);
extern tp_LocPVal FilPVal_ValLocPVal(tp_FilPVal);
extern void Set_FilPVal_DataLocHdr(tp_FilPVal, tp_LocHdr);
extern tp_LocHdr FilPVal_DataLocHdr(tp_FilPVal);
extern tp_FilPVal FilPVal_Father(tp_FilPVal);
extern tp_FilPVal FilPVal_DerefPrmVal(tp_FilPVal, tp_PrmTyp);
extern void Chain_FilPVal_DerefPrmVal(tp_LocInp *, tp_LocInp *, tp_FilPVal, tp_FilHdr);
/* if-filtyp.c */
extern tp_TClass Tool_TClass(tp_Tool);
extern tp_InpEdg Tool_InpEdg(tp_Tool);
extern tp_Package Tool_Package(tp_Tool);
extern bool IsDerefInput_Tool(tp_Tool);
extern bool IsReport_Tool(tp_Tool);
extern bool IsDerefPrmVal_Tool(tp_Tool);
extern tp_Status Get_ToolStatus(tp_Tool, tp_Status);
extern tp_FilTyp Key_FilTyp(tp_Key);
extern void Key_InstanceLabel(tp_Str, tp_Key);
extern tp_FilTyp FTName_FilTyp(tp_FTName);
extern void Build_Label(tp_Str, tp_Ident, tp_FilTyp, tp_LocHdr, bool);
extern tp_LocHdr CacheFileName_LocHdr(tp_FileName);
extern void SetFilHdr_DrvMarks(tp_FilHdr);
extern void SetFilHdr_Marks(tp_FilHdr, bool);
extern void SetFilTyp_Marks(tp_FilTyp, bool, bool);
extern void SetFilTyp_Mark(tp_FilTyp);
extern void WriteSrcFilTyps(tp_FilDsc, bool);
extern void Clr_FilTypMarks();
extern void WriteMarkedFilTyps(tp_FilDsc);
extern tp_FilTyp Nod_FilTyp(tp_Nod);
/* if-ft.c */
extern bool IsPntr_FKind(tp_FKind);
extern bool CanPntrHo_FKind(tp_FKind);
extern bool IsATgt_FKind(tp_FKind);
extern bool IsVTgt_FKind(tp_FKind);
extern bool IsATgtText_FKind(tp_FKind);
extern bool IsVTgtText_FKind(tp_FKind);
extern bool IsExternal_Tool(tp_Tool);
extern bool IsMap_Tool(tp_Tool);
extern tp_FTName FilTyp_ShortFTName(tp_FilTyp);
extern tp_FTName FilTyp_FTName(tp_FilTyp);
extern tp_MemEdg FilTyp_MemEdg(tp_FilTyp);
extern tp_CastEdg FilTyp_CastEdg(tp_FilTyp);
extern tp_PrmTypLst FilTyp_MapPrmTypLst(tp_FilTyp);
extern tp_FilTyp FilTyp_ArgFilTyp(tp_FilTyp);
extern tp_Tool FilTyp_Tool(tp_FilTyp);
extern bool IsCopy_FilTyp(tp_FilTyp);
extern bool IsGrouping_FilTyp(tp_FilTyp);
extern bool IsGroupingInput_FilTyp(tp_FilTyp);
extern bool IsSecOrd_FilTyp(tp_FilTyp);
extern bool IsExec_FilTyp(tp_FilTyp);
extern bool IsVoid_FilTyp(tp_FilTyp);
extern bool IsAtmc_FilTyp(tp_FilTyp);
extern bool IsPntr_FilTyp(tp_FilTyp);
extern bool IsList_FilTyp(tp_FilTyp);
extern bool IsDrvDir_FilTyp(tp_FilTyp);
extern bool IsStruct_FilTyp(tp_FilTyp);
extern bool IsStructMem_FilTyp(tp_FilTyp);
extern bool IsGeneric_FilTyp(tp_FilTyp);
extern bool IsPipe_FilTyp(tp_FilTyp);
/* if-get.c */
extern void GetAllReqs(tp_FilHdr, tp_InpKind);
/* if-help.c */
extern void Do_Help(bool *, bool *, bool *, tp_Nod);
extern void Local_Next_OdinFile(tp_Str, int);
/* if-hook.c */
extern void NestedHooks(tp_FilHdr, tp_FilHdr, tp_FilDsc, tp_FilDsc, tp_FilPrm);
extern void ExpandHooks(tp_FilDsc, tp_FilDsc, tp_FilHdr);
/* if-info.c */
extern void Hash_Item(tp_Item, tp_Loc);
extern void UnHash_Item(tp_Item);
extern tp_Item Lookup_Item(tp_Loc);
extern void Append_DataNum(tp_Str, int);
extern tp_Loc Alloc(int);
extern tp_LocStr WriteStr(tp_Str);
extern tp_Str ReadStr(tp_LocStr);
extern void WritePrmInf(tp_PrmInf, tp_LocPrm);
extern void ReadPrmInf(tp_PrmInf, tp_LocPrm);
extern void WritePValInf(tp_PValInf, tp_LocPVal);
extern void ReadPValInf(tp_PValInf, tp_LocPVal);
extern void WriteHdrInf(tp_HdrInf, tp_LocHdr);
extern void ReadHdrInf(tp_HdrInf, tp_LocHdr);
extern void WriteInpInf(tp_InpInf, tp_LocInp);
extern void ReadInpInf(tp_InpInf, tp_LocInp);
extern void WriteElmInf(tp_ElmInf, tp_LocElm);
extern void ReadElmInf(tp_ElmInf, tp_LocElm);
extern void Init_Info(bool *);
extern void Close_Info();
extern void Update_Info();
/* if-io.c */
extern bool GetIsTTY();
extern tp_FilDsc FileName_CFilDsc(tp_FileName);
extern tp_FilDsc FileName_WFilDsc(tp_FileName, bool);
extern tp_FilDsc FileName_WBFilDsc(tp_FileName, bool);
extern tp_FilDsc FileName_AFilDsc(tp_FileName, bool);
extern tp_FilDsc FileName_RFilDsc(tp_FileName, bool);
extern tp_FilDsc FileName_RWFilDsc(tp_FileName, bool);
extern tp_FilDsc FileName_RWBFilDsc(tp_FileName, bool);
extern void Flush(tp_FilDsc);
extern void Rewind(tp_FilDsc);
extern void Unwind(tp_FilDsc);
extern void Close(tp_FilDsc);
extern bool EndOfFile(tp_FilDsc);
extern void Write(tp_FilDsc, tp_Str);
extern void Writech(tp_FilDsc, char);
extern void WriteInt(tp_FilDsc, int);
extern void Writeln(tp_FilDsc, const char *);
extern void WriteLine(tp_FilDsc, tp_Str);
extern int Readch(tp_FilDsc);
extern tp_Str ReadLine(tp_Str, tp_FilDsc);
extern void FileCopy(tp_FilDsc, tp_FilDsc);
/* if-ipc.c */
extern bool IsServerPId(int);
extern void IPC_Init();
extern int IPC_Read(int, char *, int);
extern void IPC_Get_Commands(bool *, char *);
extern void IPC_Write_Int(bool *, int);
extern void IPC_Write_Bool(bool *, bool);
extern void IPC_Read_Int(bool *, int *);
extern void IPC_Read_Bool(bool *, bool *);
extern void IPC_Write_Str(bool *, const char *);
extern void IPC_Read_Str(bool *, char *);
extern void IPC_Do_Abort();
extern void IPC_Close(tp_ClientID);
extern void IPC_Finish();
/* if-lex.c */
extern bool IsWordChr(char);
extern void FileError(tp_Str);
extern void ParseError(tp_Str);
extern void Init_Lex();
extern void EndLex();
extern int Lex();
extern void Unlex(tp_Str, tp_Str);
extern void Print_Unlex(tp_FilDsc, tp_Str);
/* if-lvl.c */
extern bool IsSubType(tp_FilTyp, tp_FilTyp);
extern void Do_Search(tp_DrvPth *, bool *, tp_FKind, tp_FilTyp, tp_FilTyp);
/* if-main.c */
extern void InterruptAction();
extern void TopLevelCI(bool *, tp_Str);
extern void Get_Commands(bool *);
extern int main(int, char **);
/* if-nod.c */
extern void Ret_Nod(tp_Nod);
extern tp_NodTyp Nod_NodTyp(tp_Nod);
extern void Set_Nod_NodTyp(tp_Nod, tp_NodTyp);
extern tp_Nod Nod_FirstSon(tp_Nod);
extern void Set_Nod_FirstSon(tp_Nod, tp_Nod);
extern tp_Nod Nod_Brother(tp_Nod);
extern void Set_Nod_Brother(tp_Nod, tp_Nod);
extern int Nod_NumSons(tp_Nod);
extern tp_Nod Nod_Son(int, tp_Nod);
extern tp_Sym Nod_Sym(tp_Nod);
extern void Set_Nod_Sym(tp_Nod, tp_Sym);
extern void Init_ConstructTree();
extern tp_Nod End_ConstructTree();
extern void Action(int, int);
/* if-oclex.c */
extern tp_Nod OC_Parser(tp_Str, tp_FileName, int *);
extern int OC_Lex();
extern void OC_Unparse(tp_Str, tp_Nod);
/* if-pfilhdr.c */
extern tp_PrmFHdr New_PrmFHdr(tp_FilHdr, tp_FilPrm);
extern void Use_PrmFHdr(tp_FilHdr *, tp_FilPrm *, tp_PrmFHdr);
extern bool PrmFHdrs_InUse();
/* if-prmtyp.c */
extern tp_PTName PrmTyp_PTName(tp_PrmTyp);
extern tp_FilTyp PrmTyp_FilTyp(tp_PrmTyp);
extern bool IsFirst_PrmTyp(tp_PrmTyp);
extern int PrmTyp_I(tp_PrmTyp);
extern void SetPrmTyp_Mark(tp_PrmTyp);
extern tp_FilHdr PrmTyp_StrDirFilHdr(tp_PrmTyp);
extern tp_FilPVal PrmTyp_RootFilPVal(tp_PrmTyp);
extern void SetPrmTyp_RootLocPVal(tp_PrmTyp, tp_LocPVal);
extern void SetFilHdr_PrmTypMarks(tp_FilHdr);
extern void Clr_PrmTypMarks();
extern void WriteMarkedPrmTyps(tp_FilDsc);
extern tp_PrmTyp Nod_PrmTyp(tp_Nod);
/* if-rbs.c */
extern tp_Str Host_HostName(tp_Host);
extern int Host_FD(tp_Host);
extern tp_Host Host_Next(tp_Host);
extern tp_Host Lookup_Host(tp_Str);
extern tp_Host PId_Host(int);
extern void RBS_Done(tp_Host);
extern void RBS_Get_Msg(tp_Host);
extern void RBS_Do_Build(tp_Host, int, tp_FileName, tp_FileName, char **);
extern void RBS_Abort_Build(tp_Host, int);
extern void RBS_VarDef(tp_Str);
/* if-symbol.c */
extern tp_Str GetEnv(tp_Str);
extern tp_Str Malloc_Str(const char *);
extern bool Is_EmptyStr(tp_Str);
extern int Str_PosInt(tp_Str);
extern tp_Str Tail(tp_Str);
extern void StrShift(tp_Str, int);
extern tp_Sym Str_Sym(tp_Str);
extern tp_Str Sym_Str(tp_Sym);
extern int Sym_Att(tp_Sym);
extern void Set_Sym_Att(tp_Sym, int);
extern void Write_Syms(tp_FilDsc);
/* if-system.c */
extern void Init_Sigs(bool);
extern void Block_Signals();
extern void Unblock_Signals();
extern void Lose_ControlTTY();
extern int SystemExec(const char *, char * const *, const char *);
extern int SystemExecCmd(const char *, bool);
extern void SystemWait(int *, bool *);
extern void SystemInterrupt(int);
extern tp_Str GetHome(tp_Str);
extern int Await_Event(fd_set *, bool);
/* if-systools.c */
extern void WriteCat(tp_FilDsc, tp_FilHdr);
extern void WriteFlat(tp_FilDsc, tp_FilHdr);
extern void WriteNames(tp_FilDsc, tp_FilHdr, tp_FilPrm);
extern void WriteLabels(tp_FilDsc, tp_FilHdr);
extern tp_LocElm Make_UnionLocElm(tp_FilHdr, tp_FilHdr);
extern void Clr_UnionFlags(tp_FilHdr);
extern void Exec_List(tp_FilHdr, tp_FilHdr, tp_FilPrm, bool);
extern void Exec_TargetsPtr(tp_FilHdr, tp_FilHdr);
extern void Exec_Targets(tp_FilDsc, tp_FileName);
extern void WriteSrcNames(tp_FilDsc, tp_FileName, bool);
extern void Validate_ViewSpec(tp_FilHdr);
extern tp_FilElm FilElm_NextStrFilElm(tp_FilElm);
extern void Exec_CmptView(bool *, tp_FilHdr, tp_FilHdr);
extern void Install_ActTgt(tp_FilHdr);
extern void Uninstall_ActTgt(tp_FilHdr);
extern void WriteTextDef(tp_FilHdr, tp_FilDsc, tp_FileName, tp_FilDsc, tp_FileName);
extern tp_LocElm Make_TargetsLocElm(tp_FilHdr, tp_FilDsc, tp_FileName, tp_Date, bool);
extern void Exec_VirDir(tp_FilHdr, tp_FilHdr);
extern void FilPVal_LocElm(tp_LocElm *, tp_LocElm *, tp_FilPVal, tp_FilHdr);
extern tp_LocElm Make_PntrHoLocElm(tp_FilHdr, tp_FilHdr);
extern tp_LocElm Make_DerefPrmValLocElm(tp_FilHdr, tp_FilHdr);
extern tp_LocElm Make_RecurseLocElm(tp_FilHdr, tp_FilHdr);
extern tp_LocElm Make_ExDelLocElm(tp_FilHdr, tp_FilHdr, bool);
/* if-update.c */
extern void Do_Update(tp_FilHdr, tp_OutFilHdrs, int, tp_Job, tp_Status, tp_Date, bool);
extern void Validate_IsPntr(tp_FilHdr);
extern void Update_RefFile(tp_FilHdr, tp_Status, tp_Date);
extern void Set_DrvDirConfirm(tp_FilHdr, tp_Status);
extern void Set_ListStatus(tp_FilHdr, tp_Status);
/* if-inotify.c */
int Create_Inotify_Fd();
void Inotify_Watch_Dir(tp_FileName FileName);
void Inotify_Watch_File(tp_FileName FileName);
char const* Inotify_Get_Next_Change();

/* if-util.c */
extern void Local_Redo(tp_Str);
extern void Local_OdinExpr_ID(int *, tp_Str);
extern void Local_ID_OdinExpr(tp_Str, int);
extern void Local_ID_LongOdinExpr(tp_Str, int);
extern void Do_Log(const char*, tp_FilHdr, tp_LogLevel);

extern tp_FilHdr OdinExpr_FilHdr(const char *);
// like OdinExpr_FilHdr but does not extend FilHdr tree, instead
// return false if FilHdr not already known  or not a source file
// (and leaves FilHdr alone)
extern bool OdinExpr_Existing_Src_FilHdr(const char *, /*out*/ tp_FilHdr * FilHdr);

extern void WritePrmOdinExpr(tp_FilDsc, tp_FilHdr, tp_FilPrm);
extern void Local_Set_Debug(tp_Str);
extern void Local_Get_Status(tp_Status *, tp_Status *, int);
extern void Local_Get_Elements(int);
extern void Local_Get_ElementsOf(int);
extern void Local_Get_Inputs(int);
extern void Local_Get_Outputs(int);
extern void Debug_Alloc_ElmInf(tp_LocElm, tp_LocElm);
extern void Debug_Ret_ElmInf(tp_LocElm);
extern void Validate_LocElm(tp_FilHdr, tp_LocElm);
extern void Print_OdinExpr(tp_LocHdr, tp_FilPrm);
extern void printte(tp_LocHdr);
/* if-var.c */
extern void Init_Vars();
extern void Local_LogMessage(char *);
extern void Local_FileErrMessage(tp_FileName);
extern void ShowVars();
extern void HelpVar(tp_Nod);
extern void ShowVar(tp_Nod);
extern void SetVar(bool *, tp_Str, tp_Str);
extern void Set_HostVar(bool *, tp_Str, tp_Str);
/* if-yylex.c */
extern tp_Nod YY_Parser(const char *, tp_FileName, int *);
extern int YY_Lex();
extern void YY_Unparse(tp_Str, tp_Nod);
/* client.yacc.c */
extern tp_Nod OC_Parse();
extern void ocerror(char *);
extern int oclex();
extern int ocparse();
/* fsys.yacc.c */
extern tp_Nod YY_Parse();
extern void yyerror(char *);
extern int yylex();
extern int yyparse();
/* stub.in.c */
extern void IPC_Do_Msg(bool *, int);
extern void LocalEnd_Get_OdinFile(tp_FileName, tp_Status, bool);
/* stub.out.c */
extern void Add_BuildArg(tp_FileName);
extern void Do_Build(tp_JobID, tp_FileName, tp_FileName);
extern void Abort_Build(tp_JobID);
extern void Do_MakeReadOnly(tp_FileName);
extern void ErrMessage(char *);
extern void LogMessage(char *);
extern void FileErrMessage(tp_FileName);
extern void Next_OdinFile(tp_Str, int);
extern void Get_UseCount(int *);
extern void Get_CurSize(int *);
extern void ShutDown();
extern void Get_Banner(tp_Str);
extern void Do_Interrupt(bool);
extern void Do_Alias(tp_FileName, bool);
extern void Get_Alias(tp_FileName, tp_FileName);
extern void Job_Done(tp_JobID, bool);
extern void Test(tp_FileName);
extern void Test_All();
extern void Get_OdinFile(tp_FileName, tp_Status *, bool *, tp_Str, bool);
extern void Set_CWD(tp_FileName);
extern void Push_Context(tp_FileName, tp_FileName);
extern void Pop_Context(tp_FileName);
extern void Set_KeepGoing(int);
extern void Set_ErrLevel(int);
extern void Set_WarnLevel(int);
extern void Set_LogLevel(tp_LogLevel);
extern void Set_HelpLevel(int);
extern void Set_Debug(tp_Str);
extern void Set_MaxJobs(int);
extern void Redo(tp_Str);
extern void OdinExpr_ID(int *, tp_Str);
extern void ID_OdinExpr(tp_Str, int);
extern void ID_LongOdinExpr(tp_Str, int);
extern void Get_Status(tp_Status *, tp_Status *, int);
extern void Get_Elements(int);
extern void Get_ElementsOf(int);
extern void Get_Inputs(int);
extern void Get_Outputs(int);
extern void Get_DPath(tp_Str);
/* editline/complete.c */
extern char *rl_complete(char *, int *);
extern int rl_list_possib(char *, char ***);
/* editline/editline.c */
extern void rl_reset_terminal(char *);
extern void rl_initialize();
extern char *readline(const char *);
extern void add_history(char *);
/* editline/sysunix.c */
extern void rl_ttyset(int);
extern void rl_add_slash(char *, char *);

#endif
