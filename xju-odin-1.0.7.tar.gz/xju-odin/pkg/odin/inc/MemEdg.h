#ifndef TPS_MEMEDG
#define TPS_MEMEDG


typedef struct _tps_MemEdg {
   tp_FilTyp FilTyp;
   tp_MemEdg Next;
   }				tps_MemEdg;

#endif
