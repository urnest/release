#ifndef TPS_CASTEDG
#define TPS_CASTEDG

typedef struct _tps_CastEdg {
   tp_FilTyp FilTyp;
   tp_CastEdg Next;
   }				tps_CastEdg;

#endif
