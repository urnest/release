#ifndef TP_FLAG
#define TP_FLAG

/* not more than #bits/word (i.e. 32) of these */

#define		FLAG_Pending 1
#define		FLAG_DeRef 2
#define		FLAG_SymLink 3
#define		FLAG_Get 4
#define		FLAG_Union 5
#define		FLAG_Visit 6
#define		FLAG_ElmVisit 7
#define		FLAG_ElmNameVisit 8

#endif
