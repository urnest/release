package e;

import d.*;

public class k {
    ax kf() { return null; }
    ax.s kf2() { return null; }
}
