extern boolean		DumpCore;
extern tp_FilDsc	StdInFD;
extern tp_FilDsc	StdErrFD;
extern tp_FilDsc	StdOutFD;
extern tp_FilDsc	ErrFD;
