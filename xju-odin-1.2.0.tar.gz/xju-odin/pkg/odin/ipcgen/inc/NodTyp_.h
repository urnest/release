#ifndef TP_YYNODTYP
#define TP_YYNODTYP

#define NOD_ident 1
#define NOD_stubs 2
#define NOD_server 3
#define NOD_client 4
#define NOD_request 5
#define NOD_splitrequest 6
#define NOD_notice 7
#define NOD_args 8
#define NOD_argdcls 9
#define NOD_argdcl 10
#define NOD_in 11
#define NOD_out 12
#define NOD_inout 13
#define NOD_int 14
#define NOD_str 15
#define NOD_pointer 16
#define NOD_proc_call 17

#endif
