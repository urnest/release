#ifndef TPS_ITEM
#define TPS_ITEM

typedef struct _tps_Item {
   tp_Loc Loc;
   tp_Item NextHash;
   }				tps_Item;

#endif
