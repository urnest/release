#ifndef TP_MODKIND
#define TP_MODKIND

#define				MODKIND_Elm 1
#define				MODKIND_ElmName 2
#define				MODKIND_Input 3

#endif
