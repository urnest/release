#ifndef TPS_FILENAME
#define TPS_FILENAME

#define				MAX_FileName 1024
typedef char 			tps_FileName [MAX_FileName];

#endif
