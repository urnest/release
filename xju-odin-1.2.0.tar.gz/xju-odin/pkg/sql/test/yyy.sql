delete from fred;
insert into fred set c1=3;
select * from fred;
