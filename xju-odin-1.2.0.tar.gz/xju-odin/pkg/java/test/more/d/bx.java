package d;

public class bx {
    ax a_;
}
