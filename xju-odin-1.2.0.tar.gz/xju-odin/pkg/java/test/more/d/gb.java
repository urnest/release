package d;

import d.g.G;

public class gb {
    public static int f() { return new G().f(); }
}
