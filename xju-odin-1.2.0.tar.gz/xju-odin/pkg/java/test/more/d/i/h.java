package d.i;

public class h {
    public static int f() { return 4; }
}
