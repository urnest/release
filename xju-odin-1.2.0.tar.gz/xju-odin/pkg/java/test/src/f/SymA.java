package f;

public class SymA {
    public static void main(String[] args) {
        assert args.length==1 : args;
    }
}
