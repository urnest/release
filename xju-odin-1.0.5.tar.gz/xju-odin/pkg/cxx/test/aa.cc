#include "aa.h"

std::string aa() throw()
{
  return "a";
}

