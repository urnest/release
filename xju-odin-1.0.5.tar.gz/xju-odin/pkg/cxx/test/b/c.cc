#include "c.h"

std::string c() throw()
{
  return "c";
}
