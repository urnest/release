package d;

public class g {
    public static class G {
        public int f() { return 3; }
    }
}
