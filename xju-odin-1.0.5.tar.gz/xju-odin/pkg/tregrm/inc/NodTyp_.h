#ifndef TP_YYNODTYP
#define TP_YYNODTYP

#define PROGRM 1
#define NOD_Include 2
#define SCANNR 3
#define EOFLDF 4
#define ERRLDF 5
#define NONLDF 6
#define LEAFDF 7
#define NODES 8
#define RULES 9
#define RULE 10
#define ALTLST 11
#define ALTRNT 12
#define SEQ 13
#define LIST 14
#define PLUS 15
#define STAR 16
#define QUESTION 17
#define OPTNAL 18
#define OUTNOD 19
#define NAME 20
#define DSTRNG 21
#define KSTRNG 22

#endif
