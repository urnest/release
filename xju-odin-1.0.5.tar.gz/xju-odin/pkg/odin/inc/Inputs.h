#ifndef TP_INPUTS
#define TP_INPUTS

#include "IOTyp.h"

typedef tp_FilTyp	tps_InpTyps [MAX_Inputs];

typedef tp_FilHdr	tps_InpFilHdrs [MAX_Inputs];

#endif
