#ifndef TPS_SRCTYP
#define TPS_SRCTYP

typedef struct _tps_SrcTyp {
   tp_Pattern Pattern;
   boolean IsPrefix;
   tp_FilTyp FilTyp;
   }				tps_SrcTyp;

#endif
