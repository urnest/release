#ifndef TP_FTCLASS
#define TP_FTCLASS

#define	FTC_None 1
#define	FTC_Atmc 2
#define	FTC_List 3
#define	FTC_Void 4
#define	FTC_Pntr 5
#define	FTC_Exec 6
#define	FTC_Generic 7
#define	FTC_Pipe 8
#define	FTC_DrvDir 9
#define	FTC_Struct 10
#define	FTC_ViewSpec 11

#endif
