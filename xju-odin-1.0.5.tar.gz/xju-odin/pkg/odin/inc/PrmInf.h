#ifndef TPS_PRMINF
#define TPS_PRMINF

typedef struct _tps_PrmInf {
   tp_LocPrm Father;

   int IPrmTyp;
   tp_LocPVal LocPVal;
   }				tps_PrmInf;

#endif
