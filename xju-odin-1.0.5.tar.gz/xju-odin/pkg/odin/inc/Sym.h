#ifndef TPS_SYM
#define TPS_SYM


typedef struct _tps_Sym {
   tp_Str Str;
   int Att;
   tp_Sym Next;
   }				tps_Sym;

#endif
