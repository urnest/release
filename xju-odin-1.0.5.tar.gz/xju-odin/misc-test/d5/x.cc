#include <hcp/tags/y.h>

int main(int argc,char*argv[])
{
  return 0;
}
