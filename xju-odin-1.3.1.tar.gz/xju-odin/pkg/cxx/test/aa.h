#ifndef _AA_H_
#define _AA_H_

#include <string>

std::string aa() throw();

#endif
