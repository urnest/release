#ifndef TP_SKIND
#define TP_SKIND

enum SKind {
  SK_NoFile=1,
  SK_Reg=2,
  SK_Dir=3,
  SK_Exec=4,
  SK_SymLink=5,
  SK_Special=6
};

#endif
