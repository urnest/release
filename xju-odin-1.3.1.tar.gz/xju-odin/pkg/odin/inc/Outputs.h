#ifndef TP_OUTPUTS
#define TP_OUTPUTS

#include <dg/inc/IOTyp.h>

typedef tp_FilTyp	tps_OutTyps [MAX_Outputs];

typedef tp_FilHdr	tps_OutFilHdrs [MAX_Outputs];

#endif
