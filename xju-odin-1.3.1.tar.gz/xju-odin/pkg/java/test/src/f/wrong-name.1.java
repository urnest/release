package f;

public class WrongName {
}
