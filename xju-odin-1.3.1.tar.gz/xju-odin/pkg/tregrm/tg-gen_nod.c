/*
Copyright (C) 1991 Geoffrey M. Clemm

This file is part of the Odin system.

The Odin system is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License
as published by the Free Software Foundation (see the file COPYING).

The Odin system is distributed WITHOUT ANY WARRANTY, without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

geoff@boulder.colorado.edu
*/

#include <gmc/gmc.h>
#include <tregrm/inc/NodTyp_.h>
#include <tregrm/inc/TokTyp_.h>
#include <gmc/nod.h>
#include <tregrm/inc/Type.hh>
#include <tregrm/inc/Func.hh>


void
Gen_NodeTypes(FilDsc, Nodes_Nod)
   tp_FilDsc FilDsc;
   tp_Nod Nodes_Nod;
{
   tp_Nod NodeType_Nod;
   int i;

   Write(FilDsc, "#ifndef TP_YYNODTYP\n#define TP_YYNODTYP\n\ntypedef enum NodTyp {");
   for (i=1; i<=Nod_NumSons(Nodes_Nod); i++) {
      if (i>1) {
         Write(FilDsc, ",\n");
      }
      else {
         Write(FilDsc, "\n");
      }
      NodeType_Nod = Nod_Son(i, Nodes_Nod);
      Write(FilDsc, "  ");
      Write(FilDsc, Sym_Str(Nod_Sym(NodeType_Nod)));
      Write(FilDsc, "=");
      WriteInt(FilDsc, i); }/*for*/;
   Write(FilDsc, "\n} tp_NodTyp;\n\n#endif\n");
   }/*Gen_NodeTypes*/


