#ifndef TP_MARKTYP
#define TP_MARKTYP

enum MarkTyp {
  MT_Null=0,
  MT_Active=1,
  MT_Complete=2,
  MT_Recursive=3
};

#endif
