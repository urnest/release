#!/usr/bin/env python3
from sys import path
del path[0]

import y
import b
from c import g
from b import q

print('x: OK')
