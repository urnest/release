#ifndef DG_MAIN_H
#define DG_MAIN_H

#ifdef __cplusplus
extern "C"
{
#endif

  int c_main(int arg, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif
