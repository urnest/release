#include "inc/GMC.h"
#include "inc/if-main.h"

int main(int argc, char* argv[])
{
  return c_main(argc, argv);
}
