#ifndef TP_YYNODTYP
#define TP_YYNODTYP

#define NSTDEF 1
#define FILDEF 2
#define SEGDEF 3
#define EXEDEF 4
#define TEXDEF 5
#define ETXDEF 6
#define DRVFLS 7
#define DRVFIL 8
#define EMPFIL 9
#define ARTFIL 10
#define ABSFIL 11
#define PRMOPR 12
#define APLOPR 13
#define DRVOPR 14
#define HODOPR 15
#define ELMOPR 16
#define DIROPR 17
#define SEGOPR 18
#define OPRTNS 19
#define PRMVLS 20
#define STRING 21
#define HOSTWD 22
#define WORD 23
#define OBJTID 24

#endif
