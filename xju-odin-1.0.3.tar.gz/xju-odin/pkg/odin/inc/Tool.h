#ifndef TPS_TOOL
#define TPS_TOOL

typedef struct _tps_Tool {
   tp_TClass TClass;
   tp_InpEdg InpEdg;
   tp_PrmTypLst PrmTypLst;
   tp_EnvVarLst EnvVarLst;
   tp_Package Package;
   }				tps_Tool;

#endif
