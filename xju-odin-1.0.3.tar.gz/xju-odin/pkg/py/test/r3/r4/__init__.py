def f():
    pass
