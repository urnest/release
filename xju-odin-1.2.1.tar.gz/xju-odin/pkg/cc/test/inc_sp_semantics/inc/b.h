#error "wrong b.h included - should get b.h not inc/b.h"
