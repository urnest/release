#include "inc/dg-main.h"

int main(int argc, char* argv[])
{
  return c_main(argc, argv);
}
