#ifndef TP_PTYPE
#define TP_PTYPE

#define				PT_Inp 1
#define				PT_Cast 2
#define				PT_Eqv 3
#define				PT_Drv 4

#endif
