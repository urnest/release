#ifndef TPS_STR
#define TPS_STR

#define				MAX_Str 10000
typedef char 			tps_Str [MAX_Str];

#endif
