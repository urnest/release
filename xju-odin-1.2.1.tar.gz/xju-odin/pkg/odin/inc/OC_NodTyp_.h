#ifndef TP_OCNODTYP
#define TP_OCNODTYP

#define CMANDS 1
#define NULLCD 2
#define DISPLY 3
#define COPYTR 4
#define EDIT 5
#define COPYTL 6
#define EXECUT 7
#define UTILTY 8
#define VARVAL 9
#define VARSET 10
#define HELP 11
#define EPHELP 12
#define SFHELP 13
#define PFHELP 14
#define DRVFIL 15
#define EMPFIL 16
#define ARTFIL 17
#define ABSFIL 18
#define PRMOPR 19
#define APLOPR 20
#define DRVOPR 21
#define HODOPR 22
#define ELMOPR 23
#define DIROPR 24
#define SEGOPR 25
#define OPRTNS 26
#define PRMVLS 27
#define PVLFIL 28
#define STRING 29
#define HOSTWD 30
#define WORD 31
#define OBJTID 32

#endif
