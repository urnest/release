package f;

public class c {
    public static int f() {
        return 2;
    }
}
