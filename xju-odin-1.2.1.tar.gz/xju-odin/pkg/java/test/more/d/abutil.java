package d;

public class abutil {
}
