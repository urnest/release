#ifndef TP_YYTOKTYP
#define TP_YYTOKTYP

#define TOK_EOF 0
#define TOK_ERR 1
#define TOK_EOF_ 2
#define TOK_ERR_ 3
#define TOK_INCLUDE 4
#define TOK_SCANNER 5
#define TOK_NODES 6
#define TOK_RULES 7
#define TOK_Name 8
#define TOK_AString 9
#define TOK_QString 10
#define TOK_Equals 11
#define TOK_DoubleArrow 12
#define TOK_SingleArrow 13
#define TOK_Plus 14
#define TOK_Star 15
#define TOK_DoubleSlash 16
#define TOK_SemiColon 17
#define TOK_Question 18
#define TOK_LeftParen 19
#define TOK_RightParen 20

#endif
