#ifndef TP_MARKTYP
#define TP_MARKTYP

#define MT_Null 0
#define MT_Active 1
#define MT_Complete 2
#define MT_Recursive 3

#endif
