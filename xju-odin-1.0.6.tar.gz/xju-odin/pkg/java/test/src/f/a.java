package f;

import d.i.h;
import d.c;
import d.ax;

public class a {
    @d.A1
    @A2
    void t1(){}

    public static void main(String args[]) {
        System.out.println(b.f()+c.f()+2+h.f());
        //        Jock x = (Fred)y;
    }
}
