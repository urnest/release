#include "twofile_2.h"

int main(int argc, char* argv[]){
  return twofile_2();
}
