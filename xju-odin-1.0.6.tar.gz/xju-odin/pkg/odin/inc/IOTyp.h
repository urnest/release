#ifndef TP_IOTYP
#define TP_IOTYP

#define			MAX_Inputs 200
#define			MAX_Outputs 100

#endif
