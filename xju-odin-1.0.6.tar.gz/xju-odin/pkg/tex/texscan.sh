#! /bin/sh

touch texnames; $1 <$2 >texnames

