def x() -> int:
    return 1
