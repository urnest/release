#error "wrong a.h included - should get inc/a.h not a.h"
