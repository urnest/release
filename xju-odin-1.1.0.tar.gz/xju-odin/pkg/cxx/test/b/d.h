#ifndef _D_H_
#define _D_H_

#include <string>

std::string d() throw();

#endif
