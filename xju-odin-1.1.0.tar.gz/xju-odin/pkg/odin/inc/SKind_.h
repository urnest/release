#ifndef TP_SKIND
#define TP_SKIND

#define				SK_NoFile 1
#define				SK_Reg 2
#define				SK_Dir 3
#define				SK_Exec 4
#define				SK_SymLink 5
#define				SK_Special 6

#endif
