drop table if exists fred;
create table fred (c1 int);
