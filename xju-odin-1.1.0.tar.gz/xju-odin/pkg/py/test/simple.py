print('simple')

