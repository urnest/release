#!/bin/sh
touch egg.py_import.view_desc
