package f;

public class SymB {
}
