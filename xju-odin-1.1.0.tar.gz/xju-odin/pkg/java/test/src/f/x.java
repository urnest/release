package f;

class x {
    void main(String args[]) {
        System.out.println(y.f());
    }
}
