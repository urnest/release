package d;

public class e
{
    public static int f() { return f.f(); }
}
