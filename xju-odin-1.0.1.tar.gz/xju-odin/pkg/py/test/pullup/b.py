from pullup.a import x

def y():
    x()
    pass
