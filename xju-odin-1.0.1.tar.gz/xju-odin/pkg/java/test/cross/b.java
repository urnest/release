public class b {
    a a_;
}
