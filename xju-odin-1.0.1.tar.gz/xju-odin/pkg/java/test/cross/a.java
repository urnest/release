public class a {
    b b_;
}
