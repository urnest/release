package e;
public class g {
    d.ax fg() { return null; }
    d.ax.s fg2() { return null; }
}
