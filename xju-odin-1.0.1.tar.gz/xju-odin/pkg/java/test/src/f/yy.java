package f;

class y {
    public static int f() {
        return 1;
    }
}
