package f;

import d.c;

public class b {
    public static int f() {
        return c.f()+c.g()+7;
    }
}
