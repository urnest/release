#ifndef TPS_EQVEDG
#define TPS_EQVEDG


typedef struct _tps_EqvEdg {
   tp_FilTyp FilTyp;
   tp_EqvEdg Next;
   }				tps_EqvEdg;

#endif
