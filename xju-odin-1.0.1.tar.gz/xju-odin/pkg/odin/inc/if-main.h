#ifndef _IF_MAIN_H_
#define _IF_MAIN_H_

#ifdef __cplusplus
extern "C" 
{
#endif

int
c_main(
  GMC_ARG(int, argc),
  GMC_ARG(char**, argv)
  );

#endif

#ifdef __cplusplus
}
#endif

