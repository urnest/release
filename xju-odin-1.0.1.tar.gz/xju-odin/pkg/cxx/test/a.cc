#include <iostream>

#include "b/b.h"
#include "aa.h"

int main(int argc, char* argv[])
{
  std::cout <<  aa() << b() << std::endl;
  return 0;
}
