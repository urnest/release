#!/bin/sh
#
cat $1 | sort -u > _set
