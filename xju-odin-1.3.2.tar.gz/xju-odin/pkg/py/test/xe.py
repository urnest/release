import y
import b
from c import g
from b import q
import e1


print('x: OK')
