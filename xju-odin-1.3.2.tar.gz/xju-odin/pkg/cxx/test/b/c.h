#ifndef _C_H_
#define _C_H_

#include <string>

std::string c() throw();

#endif
