#include "gmc/inotify.h"
#include <stdlib.h>

int Create_Inotify_Fd(){
  abort();
}

void Inotify_Watch_Dir(tp_FileName FileName){
}

void Inotify_Watch_File(tp_FileName FileName){
}
char const* Inotify_Get_Next_Change() {
  return 0;
}
