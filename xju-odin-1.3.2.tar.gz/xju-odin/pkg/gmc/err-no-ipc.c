#include <gmc/gmc.h>

void ErrMessage(tp_Str Message)
{
   Local_ErrMessage(Message);
   }/*ErrMessage*/
