#include <gmc/gmc.h>
#include <odin/inc/if-main.h>

int main(int argc, char* argv[])
{
  return c_main(argc, argv);
}
