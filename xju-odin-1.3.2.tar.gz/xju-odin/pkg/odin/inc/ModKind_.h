#ifndef TP_MODKIND
#define TP_MODKIND

enum ModKind {
  MODKIND_Elm=1,
  MODKIND_ElmName=2,
  MODKIND_Input=3
};

#endif
