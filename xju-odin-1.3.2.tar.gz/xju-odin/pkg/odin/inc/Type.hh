#ifndef ODIN_TYPE_H
#define ODIN_TYPE_H

#include <gmc/gmc.h>
#include <dg/inc/Type.hh>
#include <odin/inc/SKind_.h>
#include <odin/inc/LogLevel_.h>
#include <odin/inc/Status_.h>
#include <odin/inc/ModKind_.h>

typedef enum Status	tp_Status;
typedef enum LogLevel	tp_LogLevel;
typedef enum SKind	tp_SKind;
typedef int		tp_Flag;
typedef int		tp_ParseKind;
typedef int		tp_PrmClass;
typedef enum ModKind	tp_ModKind;

typedef int		tp_JobID;
typedef int		tp_BuildID;
typedef int		tp_ClientID;
typedef int		tp_Date;

typedef long		tp_Loc;
typedef tp_Loc		tp_LocStr;
typedef tp_Loc		tp_LocElm;
typedef tp_Loc		tp_LocHdr;
typedef tp_Loc		tp_LocPrm;
typedef tp_Loc		tp_LocPVal;
typedef tp_Loc		tp_LocInp;

typedef int *		tp_FilDsc;

typedef struct _tps_Build *	tp_Build;
typedef struct _tps_CastEdg *	tp_CastEdg;
typedef struct _tps_Client *	tp_Client;
typedef struct _tps_FHLst *	tp_FHLst;
typedef struct _tps_Pending *	tp_Pending;
typedef struct _tps_DrvEdg *	tp_DrvEdg;
typedef struct _tps_DrvPth *	tp_DrvPth;
typedef struct _tps_DrvSpc *	tp_DrvSpc;
typedef struct _tps_ElmInf *	tp_ElmInf;
typedef struct _tps_EqvEdg *	tp_EqvEdg;
typedef struct _tps_FilElm *	tp_FilElm;
typedef struct _tps_FilInp *	tp_FilInp;
typedef struct _tps_SrcTyp *	tp_SrcTyp;
typedef struct _tps_FilTyp *	tp_FilTyp;
typedef struct _tps_PrmTyp *	tp_PrmTyp;
typedef struct _tps_PrmTypLst *	tp_PrmTypLst;
typedef struct _tps_EnvVar *	tp_EnvVar;
typedef struct _tps_EnvVarLst *	tp_EnvVarLst;
typedef struct _tps_InpSpc *	tp_InpSpc;
typedef struct _tps_Host *	tp_Host;
typedef struct _tps_Item *	tp_Item;
typedef struct _tps_Job *	tp_Job;
typedef struct _tps_MemEdg *	tp_MemEdg;
typedef struct _tps_Nod *	tp_Nod;
typedef struct _tps_Pos *	tp_Pos;
typedef struct _tps_PrmFHdr *	tp_PrmFHdr;
typedef struct _tps_Parm *	tp_Parm;
typedef struct _tps_PrmInf *	tp_PrmInf;
typedef struct _tps_PValInf *	tp_PValInf;
typedef struct _tps_FilPrm *	tp_FilPrm;
typedef struct _tps_FilPVal *	tp_FilPVal;
typedef struct _tps_ExecSpc *	tp_ExecSpc;
typedef struct _tps_InpEdg *	tp_InpEdg;
typedef struct _tps_InpInf *	tp_InpInf;
typedef struct _tps_Sym *	tp_Sym;
typedef struct _tps_Tool *	tp_Tool;

typedef char *		tp_HostName;
typedef char *		tp_Label;

typedef struct _tps_FilHdr *	tp_FilHdr;
typedef struct _tps_HdrInf *	tp_HdrInf;

typedef tp_FilTyp *	tp_InpTyps;
typedef tp_FilHdr *	tp_InpFilHdrs;
typedef tp_FilTyp *	tp_OutTyps;
typedef tp_FilHdr *	tp_OutFilHdrs;

typedef tp_Pos		tp_Lvl;

#endif
