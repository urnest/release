#ifndef _IF_MAIN_H_
#define _IF_MAIN_H_

#ifdef __cplusplus
extern "C" 
{
#endif

int
c_main(int argc, char** argv);

#endif

#ifdef __cplusplus
}
#endif

