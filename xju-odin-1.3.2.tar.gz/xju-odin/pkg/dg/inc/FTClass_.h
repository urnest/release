#ifndef TP_FTCLASS
#define TP_FTCLASS

enum FTClass {
  FTC_None=1,
  FTC_Atmc=2,
  FTC_List=3,
  FTC_Void=4,
  FTC_Pntr=5,
  FTC_Exec=6,
  FTC_Generic=7,
  FTC_Pipe=8,
  FTC_DrvDir=9,
  FTC_Struct=10,
  FTC_ViewSpec=11
};

#endif
