#ifdef BUILDING_DG
#include <dg/inc/DgNodTyp_.h>
#endif
#ifdef BUILDING_ODIN
#include <odin/inc/OdinNodTyp_.h>
#endif
