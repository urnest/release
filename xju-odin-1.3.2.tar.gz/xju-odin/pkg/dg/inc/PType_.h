#ifndef TP_PTYPE
#define TP_PTYPE

enum PType {
  PT_Inp=1,
  PT_Cast=2,
  PT_Eqv=3,
  PT_Drv=4
};

#endif
