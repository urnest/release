#ifndef TP_ISKIND
#define TP_ISKIND

enum ISKind {
  ISK_Str	=1,
  ISK_Key	=2,
  ISK_Drv	=3,
  ISK_Prm	=4,
  ISK_PrmVal	=5,
  ISK_Sel	=6,
  ISK_VTgt	=7,
  ISK_EmptyFile	=8
};

#endif
