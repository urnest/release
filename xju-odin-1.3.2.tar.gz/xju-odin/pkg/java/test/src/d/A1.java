package d;

public @interface A1 {}
