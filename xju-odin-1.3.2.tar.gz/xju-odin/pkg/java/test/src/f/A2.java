package f;

public @interface A2 {}
