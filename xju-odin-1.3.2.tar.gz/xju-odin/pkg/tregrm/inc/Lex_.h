#ifndef TP_LEXTYP
#define TP_LEXTYP

#define	LX_Leaf		1
#define	LX_NonLeaf	2

#endif
