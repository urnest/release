package d;

public class f {
    public static int f() { return new g.G().f(); }
}
