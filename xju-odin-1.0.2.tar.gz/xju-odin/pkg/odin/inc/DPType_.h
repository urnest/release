#ifndef TP_DPTYPE
#define TP_DPTYPE

#define				DPT_Cast 1
#define				DPT_Eqv 2
#define				DPT_Drv 3

#endif
