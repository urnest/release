#ifndef TPS_PRMTYPLST
#define TPS_PRMTYPLST


typedef struct _tps_PrmTypLst {
   tp_PrmTyp PrmTyp;
   tp_PrmTypLst Next;
   }				tps_PrmTypLst;

#endif
