#ifndef TP_ISKIND
#define TP_ISKIND

#define ISK_Str		1
#define ISK_Key		2
#define ISK_Drv		3
#define ISK_Prm		4
#define ISK_PrmVal	5
#define ISK_Sel		6
#define ISK_VTgt	7
#define ISK_EmptyFile	8

#endif
