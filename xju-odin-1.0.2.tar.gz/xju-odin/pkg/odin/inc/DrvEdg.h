#ifndef TPS_DRVEDG
#define TPS_DRVEDG


typedef struct _tps_DrvEdg {
   tp_FilTyp FilTyp;
   tp_PrmTypLst PrmTypLst;
   tp_DrvEdg Next;
   }				tps_DrvEdg;

#endif
