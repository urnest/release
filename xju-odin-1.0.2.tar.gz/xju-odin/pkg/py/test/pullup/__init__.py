from pullup.a import x
from pullup.b import y
