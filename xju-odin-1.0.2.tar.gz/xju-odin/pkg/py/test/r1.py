def r2():
    pass
