#!/bin/sh
mysql -u $2 --password=$3 $1
